Yazılımcı Fabrikası Programı

7.Hafta Projem :

Siteme [buraya](https://serhatzunluoglu-react-axios-eticaret.netlify.app/) tıklayarak ulaşabilirsin.  

Bu projeyi nasıl yaptığımı anlattığım videoya [buradan](https://www.youtube.com/watch?v=9GZGOS75o-o&ab_channel=SerhatZunluo%C4%9Flu) ulaşabilirsin.


![alt text](https://github.com/serhatzunluoglu/7.Hafta-Redux-ve-Axios-Kullanimi-E-Ticaret/blob/85b65c79015357ca3ee2130f753068224ff22c8e/public/images/7.hafts-ss.png)
